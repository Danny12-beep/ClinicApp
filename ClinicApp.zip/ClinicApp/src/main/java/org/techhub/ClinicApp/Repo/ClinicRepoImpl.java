package org.techhub.ClinicApp.Repo;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;
import org.techhub.ClinicApp.Model.ClinicModel;

@Repository("ClinicRepo")
public class ClinicRepoImpl implements ClinicRepo {

	@Autowired
	JdbcTemplate template;
	
	@Override
	public boolean isaddpatient(final ClinicModel mod, String filename) {
		// TODO Auto-generated method stub
		int value = template.update("insert into clinic values('0',?,?,?,?,?,?,?,?,?)", new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				// TODO Auto-generated method stub
				
				String name = mod.getName();
				String age = mod.getAge();
				String dob = mod.getDob();
				String bloodgroup = mod.getBloodgroup();
				String address = mod.getAddress();
				String phone = mod.getPhone();
				String email = mod.getEmail();
				String date = mod.getDate();
				MultipartFile reports = mod.getReports();
				
				ps.setString(1, name);
				ps.setString(2, age);
				ps.setString(3, dob);
				ps.setString(4, bloodgroup);
				ps.setString(5, address);
				ps.setString(6, phone);
				ps.setString(7, email);
				ps.setString(8, date);
				ps.setString(9, reports.getOriginalFilename());
			}
		});
		if(value>0) {
			return true;
		} else {
			return false;
		}
	}
}
