package org.techhub.ClinicApp.Repo;

import org.techhub.ClinicApp.Model.ClinicModel;

public interface ClinicRepo {

	public boolean isaddpatient(ClinicModel mod, String filename);
}
