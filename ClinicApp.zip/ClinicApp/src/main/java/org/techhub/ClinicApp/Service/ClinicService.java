package org.techhub.ClinicApp.Service;

import org.techhub.ClinicApp.Model.ClinicModel;

public interface ClinicService {

	public boolean isaddpatient(ClinicModel mod, String filename);
}
