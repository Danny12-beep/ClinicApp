package org.techhub.ClinicApp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.ClinicApp.Model.ClinicModel;
import org.techhub.ClinicApp.Repo.ClinicRepo;

@Service("ClinicService")
public class ClinicServiceImpl implements ClinicService {

	@Autowired
	ClinicRepo crepo;

	@Override
	public boolean isaddpatient(ClinicModel mod, String filename) {
		// TODO Auto-generated method stub
		return crepo.isaddpatient(mod, filename);
	}

}
