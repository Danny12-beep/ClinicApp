package org.techhub.ClinicApp.controller;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.techhub.ClinicApp.Model.ClinicModel;
import org.techhub.ClinicApp.Service.ClinicService;

@Controller
public class HomeController {
	
	@Autowired
	ClinicService cservice;
	
	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException
	{
		return new ModelAndView("home");
	}
	

	@RequestMapping(value="/savepatient", method=RequestMethod.POST)
	public String isaddpatient(ClinicModel mod, HttpServletRequest req) throws IllegalStateException, IOException{
		
		ModelAndView mav = new ModelAndView();
		String filename=mod.getReports().getOriginalFilename();
				
		if(filename.isEmpty()==false)
		{
	    int index=filename.indexOf(".pdf");
	    String destinationfile="";
	    
	    if(index!=-1)
	    {
			String realPathtoUploads = req.getServletContext().getServletPath();
			String folder = realPathtoUploads + "PatientFiles";

			if (!new File(folder).exists()) {
				new File(folder).mkdir();
			}
			if (mod.getReports()!= null) 
			{
				destinationfile = folder + "\\"+ filename;
				System.out.println("Destination Folder "+destinationfile);
				File destfile = new File(destinationfile);
				mod.getReports().transferTo(destfile);
			} 
		boolean b = cservice.isaddpatient(mod, filename);
		if(b) {
			mav.addObject("response", "Record Saved Successfully...");
		}
		else {
			mav.addObject("response", "Record Not Saved...");
		}
	    }
		else
		{
			mav.addObject("error", "File Is Not Valid");
		}
	}
		
		else {

			boolean b = cservice.isaddpatient(mod, filename);
			if(b) {
				mav.addObject("response", "Record Saved Successfully...");
			}
			else {
				mav.addObject("response", "Record Not Saved...");
			}
		}
		return "home";
	}
}
