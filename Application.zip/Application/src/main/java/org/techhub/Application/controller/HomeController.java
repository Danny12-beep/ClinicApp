package org.techhub.Application.controller;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.techhub.Application.model.PatientModel;
import org.techhub.Application.service.PatientService;

@Controller
public class HomeController{

	@Autowired
	PatientService pservice;
	
	@Autowired
	ServletContext con;
	
	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
	@RequestMapping(value="/save", method = RequestMethod.POST)
	public String save(PatientModel model, Map map, String filename, HttpServletRequest request) throws IllegalStateException, IOException {
		
		filename=model.getReports().getOriginalFilename();
		
		if(filename.isEmpty()==false)
		{
		
	    int index=filename.indexOf(".pdf");
	    String destinationfile="";
	    
	    if(index!=-1)
	    {
			System.out.println("File is pdf");
			String realPathtoUploads = con.getRealPath("/");
			System.out.println("our realpath is"+realPathtoUploads);
			String folder = realPathtoUploads + "PatientFiles";

			if (!new File(folder).exists()) {
				new File(folder).mkdir();
			}
			if (model.getReports()!= null) 
			{
				destinationfile = folder + "\\"+ filename;
				System.out.println("Destination folder "+destinationfile);
				File destfile = new File(destinationfile);
				model.getReports().transferTo(destfile);
				  } 
		boolean b = pservice.isaddpatient(model, filename);
		if(b) {
			map.put("response", "Record Saved Successfully...");
		}
		else {
			map.put("response", "Record Not Saved...");
		}
	    }
		else
		{
			map.put("error", "File Is Not Valid");
		}
	}
		
		else {	
		
		boolean b = pservice.isaddpatient(model, filename);
		if(b) {
			map.put("msg", "Record Saved Successfully...");
		} else {
			map.put("msg", "Record Not Saved...");
		}}
		return "home";
	}
}
