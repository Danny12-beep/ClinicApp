package org.techhub.Application.repository;

import org.techhub.Application.model.PatientModel;

public interface PatientRepository {

	public boolean isaddpatient(PatientModel model, String filename);
}
