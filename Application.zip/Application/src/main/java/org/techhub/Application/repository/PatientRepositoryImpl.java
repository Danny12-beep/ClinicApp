package org.techhub.Application.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.techhub.Application.model.PatientModel;

@Repository("prepo")
public class PatientRepositoryImpl implements PatientRepository {

	@Autowired
	JdbcTemplate template;
	
	@Override
	public boolean isaddpatient(final PatientModel model, String filename) {
		// TODO Auto-generated method stub
		int value = template.update("insert into patient values('0',?,?,?,?,?,?,?,?,?)", new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				// TODO Auto-generated method stub
				ps.setString(1, model.getName());
				ps.setString(2, model.getAge());
				ps.setString(3, model.getDob());
				ps.setString(4, model.getBloodgroup());
				ps.setString(5, model.getAddress());
				ps.setString(6, model.getPhone());
				ps.setString(7, model.getEmail());
				ps.setString(8, model.getDate());
				ps.setString(9, model.getReports().getOriginalFilename());
			}
			
		});
		if(value>0) {
			return true;
		} else {
		return false;
		}
	}

}
