package org.techhub.Application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.techhub.Application.model.PatientModel;
import org.techhub.Application.repository.PatientRepository;

@Service("pservice")
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository prepo;
	
	@Override
	public boolean isaddpatient(PatientModel model, String filename) {
		// TODO Auto-generated method stub
		boolean b = prepo.isaddpatient(model, filename);
		return b;
	}
}
