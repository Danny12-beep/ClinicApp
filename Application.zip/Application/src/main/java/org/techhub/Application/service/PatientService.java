package org.techhub.Application.service;

import org.techhub.Application.model.PatientModel;

public interface PatientService {

	public boolean isaddpatient(PatientModel model, String filename);
}
